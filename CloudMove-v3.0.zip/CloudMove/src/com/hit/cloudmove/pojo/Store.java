package com.hit.cloudmove.pojo;

/**
 * Store entity. @author MyEclipse Persistence Tools
 */

public class Store implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer userid;
	private Integer communityid;
	private String name;
	private Long deliveryfee;
	private String icon;

	// Constructors

	/** default constructor */
	public Store() {
	}

	/** full constructor */
	public Store(Integer userid, Integer communityid, String name,
			Long deliveryfee, String icon) {
		this.userid = userid;
		this.communityid = communityid;
		this.name = name;
		this.deliveryfee = deliveryfee;
		this.icon = icon;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Integer getCommunityid() {
		return this.communityid;
	}

	public void setCommunityid(Integer communityid) {
		this.communityid = communityid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getDeliveryfee() {
		return this.deliveryfee;
	}

	public void setDeliveryfee(Long deliveryfee) {
		this.deliveryfee = deliveryfee;
	}

	public String getIcon() {
		return this.icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

}