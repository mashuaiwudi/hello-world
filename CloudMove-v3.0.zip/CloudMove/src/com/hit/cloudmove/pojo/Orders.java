package com.hit.cloudmove.pojo;

import java.sql.Timestamp;

/**
 * Orders entity. @author MyEclipse Persistence Tools
 */

public class Orders implements java.io.Serializable {

	// Fields

	private Integer id;
	private Timestamp time;
	private Integer storeid;
	private Integer serviceid;
	private Integer insuranceid;
	private Integer userid;
	private Integer totaldistance;
	private String category;
	private Integer state;
	private Double pay;
	private String files;
	private String note;
	private Integer payway;
	private Integer pickway;
	private Double mypay;
	private String addresss;
	private Timestamp deliverytime;
	private String movetime;

	// Constructors

	

	/** default constructor */
	public Orders() {
	}

	/** full constructor */
	public Orders(Timestamp time, Integer storeid, Integer serviceid,
			Integer insuranceid, Integer userid, Integer totaldistance,
			String category, Integer state, Double pay, String files,
			String note, Integer payway, Integer pickway, Double mypay,
			String addresss, Timestamp deliverytime, String movetime) {
		this.time = time;
		this.storeid = storeid;
		this.serviceid = serviceid;
		this.insuranceid = insuranceid;
		this.userid = userid;
		this.totaldistance = totaldistance;
		this.category = category;
		this.state = state;
		this.pay = pay;
		this.files = files;
		this.note = note;
		this.payway = payway;
		this.pickway = pickway;
		this.mypay = mypay;
		this.addresss = addresss;
		this.deliverytime = deliverytime;
		this.movetime = movetime;
	}

	// Property accessors
	public String getMovetime() {
		return movetime;
	}

	public void setMovetime(String movetime) {
		this.movetime = movetime;
	}
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Timestamp getTime() {
		return this.time;
	}

	public void setTime(Timestamp time) {
		this.time = time;
	}

	public Integer getStoreid() {
		return this.storeid;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getServiceid() {
		return this.serviceid;
	}

	public void setServiceid(Integer serviceid) {
		this.serviceid = serviceid;
	}

	public Integer getInsuranceid() {
		return this.insuranceid;
	}

	public void setInsuranceid(Integer insuranceid) {
		this.insuranceid = insuranceid;
	}

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Integer getTotaldistance() {
		return this.totaldistance;
	}

	public void setTotaldistance(Integer totaldistance) {
		this.totaldistance = totaldistance;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getState() {
		return this.state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Double getPay() {
		return this.pay;
	}

	public void setPay(Double pay) {
		this.pay = pay;
	}

	public String getFiles() {
		return this.files;
	}

	public void setFiles(String files) {
		this.files = files;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Integer getPayway() {
		return this.payway;
	}

	public void setPayway(Integer payway) {
		this.payway = payway;
	}

	public Integer getPickway() {
		return this.pickway;
	}

	public void setPickway(Integer pickway) {
		this.pickway = pickway;
	}

	public Double getMypay() {
		return this.mypay;
	}

	public void setMypay(Double mypay) {
		this.mypay = mypay;
	}

	public String getAddresss() {
		return this.addresss;
	}

	public void setAddresss(String addresss) {
		this.addresss = addresss;
	}

	public Timestamp getDeliverytime() {
		return this.deliverytime;
	}

	public void setDeliverytime(Timestamp deliverytime) {
		this.deliverytime = deliverytime;
	}

}