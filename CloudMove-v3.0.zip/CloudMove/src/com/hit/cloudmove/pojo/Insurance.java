package com.hit.cloudmove.pojo;

/**
 * Insurance entity. @author MyEclipse Persistence Tools
 */

public class Insurance implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private Integer storeid;
	private Integer isDel;

	// Constructors

	/** default constructor */
	public Insurance() {
	}

	/** full constructor */
	public Insurance(String name, Integer storeid, Integer isDel) {
		this.name = name;
		this.storeid = storeid;
		this.isDel = isDel;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getStoreid() {
		return this.storeid;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getIsDel() {
		return this.isDel;
	}

	public void setIsDel(Integer isDel) {
		this.isDel = isDel;
	}

}