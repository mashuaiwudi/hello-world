package com.hit.cloudmove.pojo;

/**
 * Community entity. @author MyEclipse Persistence Tools
 */

public class Community implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private Integer cityid;

	// Constructors

	/** default constructor */
	public Community() {
	}

	/** full constructor */
	public Community(String name, Integer cityid) {
		this.name = name;
		this.cityid = cityid;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getCityid() {
		return this.cityid;
	}

	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}

}