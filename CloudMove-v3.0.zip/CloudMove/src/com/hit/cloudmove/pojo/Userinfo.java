package com.hit.cloudmove.pojo;

/**
 * Userinfo entity. @author MyEclipse Persistence Tools
 */

public class Userinfo implements java.io.Serializable {

	// Fields

	private Integer id;
	private String tel;
	private String passwd;
	private String realname;
	private Integer isUser;

	// Constructors

	/** default constructor */
	public Userinfo() {
	}

	/** full constructor */
	public Userinfo(String tel, String passwd, String realname, Integer isUser) {
		this.tel = tel;
		this.passwd = passwd;
		this.realname = realname;
		this.isUser = isUser;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getPasswd() {
		return this.passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getRealname() {
		return this.realname;
	}

	public void setRealname(String realname) {
		this.realname = realname;
	}

	public Integer getIsUser() {
		return this.isUser;
	}

	public void setIsUser(Integer isUser) {
		this.isUser = isUser;
	}

}