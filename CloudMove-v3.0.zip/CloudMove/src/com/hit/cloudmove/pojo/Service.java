package com.hit.cloudmove.pojo;

/**
 * Service entity. @author MyEclipse Persistence Tools
 */

public class Service implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private Double unitprice;
	private String unitmeasure;
	private Integer storeid;
	private Integer isDel;

	// Constructors

	/** default constructor */
	public Service() {
	}

	/** full constructor */
	public Service(String name, Double unitprice, String unitmeasure,
			Integer storeid, Integer isDel) {
		this.name = name;
		this.unitprice = unitprice;
		this.unitmeasure = unitmeasure;
		this.storeid = storeid;
		this.isDel = isDel;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getUnitprice() {
		return this.unitprice;
	}

	public void setUnitprice(Double unitprice) {
		this.unitprice = unitprice;
	}

	public String getUnitmeasure() {
		return this.unitmeasure;
	}

	public void setUnitmeasure(String unitmeasure) {
		this.unitmeasure = unitmeasure;
	}

	public Integer getStoreid() {
		return this.storeid;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getIsDel() {
		return this.isDel;
	}

	public void setIsDel(Integer isDel) {
		this.isDel = isDel;
	}

}