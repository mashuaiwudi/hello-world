package com.hit.cloudmove.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hit.cloudmove.form.AddStoreForm;
import com.hit.cloudmove.pojo.Insurance;
import com.hit.cloudmove.pojo.Service;
import com.hit.cloudmove.pojo.Store;
import com.hit.cloudmove.services.InsuranceService;
import com.hit.cloudmove.services.ServiceService;
import com.hit.cloudmove.services.StoreService;

/**
 * MyEclipse Struts Creation date: 06-26-2015
 * 
 * XDoclet definition:
 * 
 * struts.action path="/addStore" name="addStoreForm"
 *                input="/form/addStore.jsp" scope="request" validate="true"
 */
public class AddStoreAction extends Action {

	private StoreService storeservice;
	private InsuranceService insuranceservice;
	private ServiceService serviceservice;


	
	public InsuranceService getInsuranceservice() {
		return insuranceservice;
	}

	public void setInsuranceservice(InsuranceService insuranceservice) {
		this.insuranceservice = insuranceservice;
	}

	public ServiceService getServiceservice() {
		return serviceservice;
	}

	public void setServiceservice(ServiceService serviceservice) {
		this.serviceservice = serviceservice;
	}
	
	public StoreService getStoreservice() {
		return storeservice;
	}

	public void setStoreservice(StoreService storeservice) {
		this.storeservice = storeservice;
	}

	/*
	 * Generated Methods
	 */

	/**
	 * Method execute
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		AddStoreForm addStoreForm = (AddStoreForm) form;
		Store store = new Store();
		store.setDeliveryfee(Long.parseLong(addStoreForm.getDeliveryPrice()));
		store.setName(addStoreForm.getStoreName());
		int userId = (Integer)request.getSession().getAttribute("userID");
		int communityId = (Integer)request.getSession().getAttribute("communityID");
		store.setUserid(userId);
		store.setCommunityid(communityId);
		int storeId = storeservice.save(store);
		if(storeId == 0)
		{
			return mapping.findForward("fail");
		}
		
		ArrayList services = addStoreForm.getServices();
		ArrayList insurances = addStoreForm.getInsurances();
		
		for(int i = 0; i < services.size();i++)
		{
			Service service = (Service)services.get(i);
			service.setStoreid(storeId);
			if(!serviceservice.save(service))
			{
				return mapping.findForward("fail");
			}		 
		}
		
		for(int i = 0; i < insurances.size();i++)
		{
			Insurance insurance = (Insurance)insurances.get(i);
			insurance.setStoreid(storeId);
			if(!insuranceservice.save(insurance))
			{
				return mapping.findForward("fail");
			}		 
		}
														// method stub
		return mapping.findForward("success");
	}
	
}
