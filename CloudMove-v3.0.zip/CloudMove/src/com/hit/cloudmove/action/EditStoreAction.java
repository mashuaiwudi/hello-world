package com.hit.cloudmove.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hit.cloudmove.pojo.Store;
import com.hit.cloudmove.services.InsuranceService;
import com.hit.cloudmove.services.ServiceService;
import com.hit.cloudmove.services.StoreService;

public class EditStoreAction extends Action {
	/*
	 * Generated Methods
	 */

	private StoreService storeservice;
	private InsuranceService insuranceservice;
	private ServiceService serviceservice;


	
	public InsuranceService getInsuranceservice() {
		return insuranceservice;
	}

	public void setInsuranceservice(InsuranceService insuranceservice) {
		this.insuranceservice = insuranceservice;
	}

	public ServiceService getServiceservice() {
		return serviceservice;
	}

	public void setServiceservice(ServiceService serviceservice) {
		this.serviceservice = serviceservice;
	}
	
	public StoreService getStoreservice() {
		return storeservice;
	}

	public void setStoreservice(StoreService storeservice) {
		this.storeservice = storeservice;
	}
	/** 
	 * Method execute
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionForward
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
        int storeid = (Integer) request.getSession().getAttribute("storeID");
        
		List services = serviceservice.getServiceListByStoreID(storeid);
		List insurances = insuranceservice.getInsuranceByStoreId(storeid);
		
		request.setAttribute("ServiceList", services);
		request.setAttribute("InsuranceList", insurances);
		
		Store store = storeservice.getStoreById(storeid);
		request.setAttribute("ThisStore", store);

	      return mapping.findForward("success");
		
	}
}
