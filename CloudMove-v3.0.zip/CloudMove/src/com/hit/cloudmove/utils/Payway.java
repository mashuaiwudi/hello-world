package com.hit.cloudmove.utils;

public class Payway implements java.io.Serializable {
private String paywayID;
private String paywayName;
public String getPaywayID() {
	return paywayID;
}
public void setPaywayID(String paywayID) {
	this.paywayID = paywayID;
}
public String getPaywayName() {
	return paywayName;
}
public void setPaywayName(String paywayName) {
	this.paywayName = paywayName;
}
public Payway(String paywayID, String paywayName) {
	super();
	this.paywayID = paywayID;
	this.paywayName = paywayName;
}

}
