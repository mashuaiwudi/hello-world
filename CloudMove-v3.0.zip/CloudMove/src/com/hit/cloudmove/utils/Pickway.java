package com.hit.cloudmove.utils;

public class Pickway implements java.io.Serializable {
private String pickwayID;
private String pickwayName;
public String getPickwayID() {
	return pickwayID;
}
public void setPickwayID(String pickwayID) {
	this.pickwayID = pickwayID;
}
public String getPickwayName() {
	return pickwayName;
}
public void setPickwayName(String pickwayName) {
	this.pickwayName = pickwayName;
}
public Pickway(String pickwayID, String pickwayName) {
	super();
	this.pickwayID = pickwayID;
	this.pickwayName = pickwayName;
}

}
