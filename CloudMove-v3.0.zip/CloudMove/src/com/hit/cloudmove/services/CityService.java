package com.hit.cloudmove.services;

import java.util.List;

import com.hit.cloudmove.DAO.CityDAO;
import com.hit.cloudmove.pojo.City;

public class CityService {
	
	private CityDAO cityDAO;

	public CityDAO getCityDAO() {
		return cityDAO;
	}

	public void setCityDAO(CityDAO cityDAO) {
		this.cityDAO = cityDAO;
	}
	
	@SuppressWarnings("unchecked")
	public List<City> findAll(){
		return cityDAO.findAll();
	}
	
}
