package com.hit.cloudmove.services;

import java.util.List;

import com.hit.cloudmove.DAO.CommunityDAO;
import com.hit.cloudmove.pojo.Community;

public class CommunityService {

	private CommunityDAO communityDAO;

	public CommunityDAO getCommunityDAO() {
		return communityDAO;
	}

	public void setCommunityDAO(CommunityDAO communityDAO) {
		this.communityDAO = communityDAO;
	}
	
	@SuppressWarnings("unchecked")
	public List<Community> getCommunityByCityID(int cityid){
		return communityDAO.findByCityid(cityid);
	}
	
	public Community getCommunityByID(int id){
		return communityDAO.findById(id);
	}
}
