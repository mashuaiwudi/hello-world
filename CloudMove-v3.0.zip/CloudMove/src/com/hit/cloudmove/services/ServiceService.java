package com.hit.cloudmove.services;

import java.util.List;

import com.hit.cloudmove.DAO.ServiceDAO;
import com.hit.cloudmove.pojo.Service;

public class ServiceService {

	private ServiceDAO serviceDAO;

	public ServiceDAO getServiceDAO() {
		return serviceDAO;
	}

	public void setServiceDAO(ServiceDAO serviceDAO) {
		this.serviceDAO = serviceDAO;
	}

	public String getNameById(Integer id) {
		Service service = serviceDAO.findById(id);
		String name = service.getName();
		return name;
	}

	public Service findById(Integer id) {
		return serviceDAO.findById(id);
	}
	
	@SuppressWarnings("unchecked")
	public boolean delByStoreId(int storeid) {
		List<Service> services = serviceDAO.findByStoreid(storeid);
		for (int i = 0; i < services.size(); i++) {
			Service item = services.get(i);
			item.setIsDel(1);
			serviceDAO.merge(item);
		}
		return true;
	}
	
	public boolean save(Service service) {
		try {
			serviceDAO.save(service);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<Service> getServiceListByStoreID(int storeid) {
		List<Service> services = serviceDAO.findByStoreid(storeid);
		for(int i = 0; i < services.size(); i++){
			Service item = services.get(i);
			if(isDEL(item)){
				services.remove(i);
				i--;
			}
		}
		return services;
	}
	
	private boolean isDEL(Service service){
		if(service.getIsDel() == null) return false;
		if(service.getIsDel() == 1) return true;
		return false;
	}

}
