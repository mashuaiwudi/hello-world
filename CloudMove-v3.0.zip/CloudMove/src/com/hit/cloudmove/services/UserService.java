package com.hit.cloudmove.services;

import java.util.List;

import com.hit.cloudmove.DAO.UserinfoDAO;
import com.hit.cloudmove.pojo.Userinfo;



public class UserService 
{
	private UserinfoDAO userDao;

	public UserinfoDAO getUserDao() {
		return userDao;
	}

	public void setUserDao(UserinfoDAO userDao) {
		this.userDao = userDao;
	}
	
	@SuppressWarnings("unchecked")
	public Userinfo isValid(Userinfo user)
	{
		List<Userinfo> result = userDao.findByExample(user);
		if(result.size() > 0)
			return result.get(0);
		else
			return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<Userinfo> findByTel(String tel){
		return userDao.findByTel(tel);
	}
	
	public boolean addUser(Userinfo user){
		
		if(findByTel(user.getTel()).size() != 0){
			return false;
		}
		
		try{
			userDao.save(user);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public Userinfo findById(Integer id){
		return userDao.findById(id);
	}

	public String findTelById(Integer userId) {
		// TODO Auto-generated method stub
		Userinfo user = userDao.findById(userId);
		return user.getTel();
	}
}
