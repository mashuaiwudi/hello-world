package com.hit.cloudmove.services;

import java.util.List;

import com.hit.cloudmove.DAO.InsuranceDAO;
import com.hit.cloudmove.pojo.Insurance;

public class InsuranceService {

	private InsuranceDAO insuranceDAO;

	public InsuranceDAO getInsuranceDAO() {
		return insuranceDAO;
	}

	public void setInsuranceDAO(InsuranceDAO insuranceDAO) {
		this.insuranceDAO = insuranceDAO;
	}

	public boolean save(Insurance insurance) {
		try {
			insuranceDAO.save(insurance);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public boolean delByStoreId(int storeid) {
		List<Insurance> services = insuranceDAO.findByStoreid(storeid);
		for (int i = 0; i < services.size(); i++) {
			Insurance item = services.get(i);
			item.setIsDel(1);
			insuranceDAO.merge(item);
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	public List<Insurance> findByStoreId(Integer storeId) {
		List<Insurance> services = insuranceDAO.findByStoreid(storeId);
		for (int i = 0; i < services.size(); i++) {
			Insurance item = services.get(i);
			if (isDEL(item)) {
				services.remove(i);
				i--;
			}
		}
		return services;
	}

	@SuppressWarnings("unchecked")
	public List<Insurance> getInsuranceByStoreId(Integer storeId) {
		List<Insurance> services = insuranceDAO.findByStoreid(storeId);
		for (int i = 0; i < services.size(); i++) {
			Insurance item = services.get(i);
			if (isDEL(item)) {
				services.remove(i);
				i--;
			}
		}
		return services;
	}

	private boolean isDEL(Insurance service) {
		if (service.getIsDel() == null)
			return false;
		if (service.getIsDel() == 1)
			return true;
		return false;
	}
	public Insurance findById(Integer id){
		return insuranceDAO.findById(id);
		
	}

}
