package com.hit.cloudmove.services;

import java.util.ArrayList;
import java.util.List;

import com.hit.cloudmove.DAO.StoreDAO;
import com.hit.cloudmove.pojo.Store;

public class StoreService {

	private StoreDAO storeDAO;

	public StoreDAO getStoreDAO() {
		return storeDAO;
	}

	public void setStoreDAO(StoreDAO storeDAO) {
		this.storeDAO = storeDAO;
	}
	
	
	public Store findStoreByID(int id){
		return storeDAO.findById(id);
	}
	public String findNameById(Integer id){
		Store s = storeDAO.findById(id);
		if(s!=null)
		    return s.getName();
		else 
			return "";
	}
	
	public Store findById(Integer id){
		return storeDAO.findById(id);
	}
	@SuppressWarnings("unchecked")
	public List<Store> getStoreListByCommunityID(int communityid){
		return storeDAO.findByCommunityid(communityid);
	}
	
	@SuppressWarnings("unchecked")
	public List<Store> getStoreListByCommunityIDandUserID(int communityid, int userid){
		List<Store> result = new ArrayList<Store>();
		result = storeDAO.findByUserid(userid);
		
		for(int i = 0; i < result.size(); i++){
			Store item = result.get(i);
			if(item.getCommunityid() != communityid){
				result.remove(i);
				i--;
			}
		}
		
		return result;
	}
	
		public int save(Store store)
	{
		try{
			storeDAO.save(store);
			
			return store.getId();
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
	
	public boolean update(Store store)
	{
		try{
			storeDAO.merge(store);
			
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public Store getStoreById(int id)
	{
		return storeDAO.findById(id);
	}


	@SuppressWarnings("unchecked")
	public List<Store> getStoreByUserId(int intValue) {
		// TODO Auto-generated method stub
		return storeDAO.findByUserid(intValue);
	}

	public Integer findUserIdByID(Integer orderId) {
		// TODO Auto-generated method stub
		Store store = storeDAO.findById(orderId);
		
		return store.getUserid();
	}
}
