package com.hit.cloudmove.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.hit.cloudmove.DAO.OrdersDAO;
import com.hit.cloudmove.pojo.Orders;
import com.hit.cloudmove.pojo.Store;
import com.hit.cloudmove.pojo.Userinfo;

public class OrderService {

	private OrdersDAO ordersDAO;

	public OrdersDAO getOrderDAO() {
		return ordersDAO;
	}

	public void setOrderDAO(OrdersDAO ordersDAO) {
		this.ordersDAO = ordersDAO;
	}

	@SuppressWarnings("unchecked")
	public List<Orders> getOrderByUserId(int id) {
		return ordersDAO.findByUserid(new Integer(id));
	}

	public Orders getOrderById(int id) {
		return ordersDAO.findById(new Integer(id));
	}

	@SuppressWarnings("unchecked")
	public List<Orders> getAll() {
		return ordersDAO.findAll();
	}

	public void addOrder(Orders order) {
		ordersDAO.save(order);
	}

	public void updateOrder(Orders order) {
		ordersDAO.merge(order);
	}

	public void setStateById(Integer id, Integer state) {
		Orders order = ordersDAO.findById(id);
		order.setState(state);
		int state1 = state.intValue();

		if ((state1 == 3) || (state1 == 4) || (state1 == 5)) {
			// SimpleDateFormat df = new
			// SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Timestamp now = new Timestamp(System.currentTimeMillis());
			order.setDeliverytime(now);
			System.out.println("state1:" + now);

		}
		ordersDAO.merge(order);
	}

	@SuppressWarnings("unchecked")
	public List<Orders> getOrderByStoreId(int id) {
		return ordersDAO.findByStoreid(new Integer(id));

	}

	@SuppressWarnings("unchecked")
	public List<Orders> getOrdersOfStores(List<Store> stores) {
		// TODO Auto-generated method stub
		List<Orders> orders = new ArrayList<Orders>();
		for (int i = 0; i < stores.size(); i++) {
			Store store = stores.get(i);
			orders.addAll(ordersDAO.findByStoreid(store.getId()));
		}
		return orders;
	}
	
	public String findTimeById(Integer id){
		List s = ordersDAO.findByMovetime(id);
		if(s!=null)
		    return s.toString();
		else 
			return "";
	}
	
	public String findMoveTimeById(Object d) {
		// TODO Auto-generated method stub
		List order = ordersDAO.findByMovetime(d);
		return order.toString();
	}
}
