package com.hit.cloudmove.test;

import com.hit.cloudmove.DAO.UserinfoDAO;

public class testDAO {

	public static void main(String[] args) {
		UserinfoDAO userinfoDAO = new UserinfoDAO();
		System.out.println(userinfoDAO.findAll().size());
	}
	
}
