package com.hit.cloudmove.util;

public interface IConstant {
	
	public static int IS_ORDINARY_USER = 1;
	public static int IS_STORE_USER = -1;
	
	public static int ORDER_STATE_NORECEIVE = 1;
	public static int ORDER_STATE_RECEIVE = 2;
	public static int ORDER_STATE_DELIEVERY = 3;
	public static int ORDER_STATE_DELIEVERYPROXY = 4;
	public static int ORDER_STATE_DELIEVERYMYSELF = 5;
	public static int ORDER_STATE_SETTLE = 6;
	public static int ORDER_STATE_APPLYCANCEL = 7;
	public static int ORDER_STATE_CANCEL = 8;
	public static int ORDER_STATE_NOCANCEL = 9;
	
	public static int PAYWAY_ONLINE = 1;
	public static int PAYWAY_OUTLINE = 2;
	
	public static int PICKWAY_DELIEVERY = 1;
	public static int PICKWAY_DELIEVERYPROXY = 2;
	public static int PICKWAY_DELIEVERYMYSELF = 3;

}
