package com.hit.cloudmove.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.NumberUtils;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

	public class UserMakeOrder1Form extends ActionForm {
		/*
		 * Generated fields
		 */

		/** insuranceId property */
		private String insuranceId;

		/** category property */
		private String category;

		/** serviceId property */
		private String serviceId;

		/** page property */
		private String page;

		/** file property */
		private String file;

		/** note property */
		private String note;


		/** payway property */
		private String payway;

		/** pickway property */
		private String pickway;


		/** address property */
		private String address;


		/** deliverypay property */
		private String deliverypay;

		/** mypay property */
		private String mypay;
		

		private String state;	
		
		private String originalpay;
		private String pay;
		
		private String time;

		private String movetime;
		
		

		private String pageType;

		private String orderId;
		
		
		/*
		 * Generated Methods
		 */

		/** 
		 * Method validate
		 * @param mapping
		 * @param request
		 * @return ActionErrors
		 */
		public ActionErrors validate(ActionMapping mapping,
				HttpServletRequest request) {
			// TODO Auto-generated method stub
			System.out.println("form2=validate");
			ActionErrors error =new ActionErrors();
			
			if(serviceId.equals(""))
				error.add("serviceId", new ActionError("user.serviceId.null"));
			//if(file.equals(""))
			//	error.add("file", new ActionError("user.file.null"));
	
			if(category.equals(""))
				error.add("category", new ActionError("user.category.null"));
			if(page.equals(""))
				error.add("page", new ActionError("user.page.null"));
			if(!NumberUtils.isDigits(page.trim()))
				error.add("page", new ActionError("user.page.digits"));
			if(address.equals(""))
				error.add("address", new ActionError("user.address.null"));
			if(mypay.equals(""))
				error.add("mypay", new ActionError("user.mypay.null"));
//			if(!NumberUtils.isNumber(mypay))
//				error.add("mypay", new ActionError("user.mypay.number"));
			return error;
		}

		/** 
		 * Method reset
		 * @param mapping
		 * @param request
		 */
		public void reset(ActionMapping mapping, HttpServletRequest request) {
			// TODO Auto-generated method stub
		}

		public String getInsuranceId() {
			return insuranceId;
		}

		public void setInsuranceId(String insuranceId) {
			this.insuranceId = insuranceId;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String getServiceId() {
			return serviceId;
		}

		public void setServiceId(String serviceId) {
			this.serviceId = serviceId;
		}

		public String getPage() {
			return page;
		}

		public void setPage(String page) {
			this.page = page;
		}

		public String getFile() {
			return file;
		}

		public void setFile(String file) {
			this.file = file;
		}

		public String getNote() {
			return note;
		}

		public void setNote(String note) {
			this.note = note;
		}

		public String getPayway() {
			return payway;
		}

		public void setPayway(String payway) {
			this.payway = payway;
		}

		public String getPickway() {
			return pickway;
		}

		public void setPickway(String pickway) {
			this.pickway = pickway;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getDeliverypay() {
			return deliverypay;
		}

		public void setDeliverypay(String deliverypay) {
			this.deliverypay = deliverypay;
		}

		public String getMypay() {
			return mypay;
		}

		public void setMypay(String mypay) {
			this.mypay = mypay;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getOriginalpay() {
			return originalpay;
		}

		public void setOriginalpay(String originalpay) {
			this.originalpay = originalpay;
		}

		public String getPay() {
			return pay;
		}

		public void setPay(String pay) {
			this.pay = pay;
		}

		public String getTime() {
			return time;
		}

		public void setTime(String time) {
			this.time = time;
		}

		public String getPageType() {
			return pageType;
		}

		public void setPageType(String pageType) {
			this.pageType = pageType;
		}

		public String getOrderId() {
			return orderId;
		}

		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}
		
		public String getMovetime() {
			return movetime;
		}

		public void setMovetime(String movetime) {
			this.movetime = movetime;
		}

}
