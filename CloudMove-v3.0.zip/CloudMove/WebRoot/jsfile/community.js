$(document).ready(function(){
	
	

	$("#citymenu li a").click(function(){
		var cityname = $(this).text();
		$("#cityname").text(cityname);
		
		$.ajax({
			 type : 'post',
			 url : "getCommunityByCityID.do",
			 data : {
				 cityid : $(this).attr("id")
			 },
			 dataType : 'json',
			 success : function(jsonObj) {
				 var str = "";
				 $("#community").text("");
				 for(var i in jsonObj){
					 str += "<option value=" + jsonObj[i]['id'] + ">" + jsonObj[i]['name'] + "</option>";
				 }
				 $("#community").append(str);

//				 $("#community option").click(function(){
//					 	alert("success");
//				 });
			 }
		});
	});
	
//	$("#community").change(function(){
//	 	alert($("#community").find('option:selected').text());
//	 	alert($("#community").find('option:selected').attr('id'));
//	});
//	
//	$("#submit").click(function(){
//		var id = $("#community").find('option:selected').attr('id');
//		alert(id);
//		enterhomepage();
//	});
//	
//	function enterhomepage(){
//		$.ajax({
//			 type : 'post',
//			 url : "enterHomePage.do",
//			 data : {
//				 id : $("#community").find('option:selected').attr('id')
//			 },
//			 dataType : 'text',
//			 success : function(jsonObj) {
//				 alert(jsonObj);
//			 }
//		});
//	}
	
	
});