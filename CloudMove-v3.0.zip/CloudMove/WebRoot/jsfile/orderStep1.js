$(document).ready(function() {
	// // 文件上传
	// $("#uploadForm").submit(function(){ // form提交事件
	// alert("start");
	// $("#uploadForm").ajaxSubmit({
	// url : "fileUpload.do",
	// beforeSubmit: function(formData, jqForm, options){ //提交前的回调函数
	// //alert("before submit---这里进行文件格式验证");
	// },
	// dataType: 'text', //html(默认), xml, script, json...接受服务端返回的类型
	// success: function(data){ //提交后的回调函数
	// alert(data);
	// },
	// //clearForm: true, //成功提交后，清除所有表单元素的值
	// resetForm: true //成功提交后，重置所有表单元素的值
	// //timeout: 3000 //限制请求的时间，当请求大于3秒后，跳出请求
	// });
	// return false;
	// });

	jQuery.noConflict(); // 解决jquery冲突问题
	function ajaxFileUpload() {
		alert("sssst");
		var fileVal = jQuery("#file").attr("value");

		var fileValArr = fileVal.split(".");
		if (fileValArr[fileValArr.length - 1] != 'xls') {
			alert("请上传excel文件！");
			return false;
		}
		jQuery("#loading").ajaxStart(function() {
			jQuery(this).show();
		})// 开始上传文件时显示一个图片
		.ajaxComplete(function() {
			jQuery(this).hide();
		});// 文件上传完成将图片隐藏起来
		jQuery.ajaxFileUpload({
			url : 'fileUpload.do',// 用于文件上传的服务器端请求地址
			secureuri : false,// 一般设置为false 这个为空ajaxfileupload中的iframe不显示
			fileElementId : 'file',// 文件上传空间的id属性 <input type="file" id="file"
									// name="file" />
			dataType : 'json',// 返回值类型 一般设置为json
			success : function(data, status) // 服务器成功响应处理函数
			{
				// 这里放入返回成功后需要处理的响应data是返回的数据
				alert(data);
				// 逻辑处理 下面是我的逻辑处理
				for ( var i = 0; i < data.length; i++) {
					var dataVal = data[i].split("--");
					var xh = dataVal[1];
					var pscj = dataVal[4];

					if (pscj == 'nothing') {
						pscj = '';
					}

					var qmcj = dataVal[5];
					if (qmcj == 'nothing') {
						qmcj = '';
					}

					var wtgyy = dataVal[6];
					if (wtgyy == 'nothing') {
						wtgyy = '';
					}

				}

			},
			error : function(data, status, e)// 服务器响应失败处理函数
			{
				// 服务器响应失败的处理信息。
			}
		});
		return false;
	}
});